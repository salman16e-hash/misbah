package com.foldercam.manager.ui.browser

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.foldercam.manager.databinding.FragmentBrowserBinding
import com.foldercam.manager.domain.FileEntry
import com.foldercam.manager.domain.FileManager
import com.foldercam.manager.domain.SafFileManager
import java.util.*

class FileBrowserFragment : Fragment() {
    private var _binding: FragmentBrowserBinding? = null
    private val binding get() = _binding!!

    private lateinit var fileAdapter: FileAdapter
    private var currentPath: String = "/" // Virtual root or actual path
    private var isGridView: Boolean = false

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentBrowserBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupRecyclerView()
        loadFiles()

        binding.swipeRefresh.setOnRefreshListener {
            loadFiles()
            binding.swipeRefresh.isRefreshing = false
        }
    }

    private fun setupRecyclerView() {
        fileAdapter = FileAdapter(
            onItemClick = { file ->
                if (file.isDirectory) {
                    currentPath = file.path
                    loadFiles()
                } else {
                    // Open file viewer
                }
            },
            onItemLongClick = { file ->
                // Show BottomSheetDialog with Rename, Delete, etc.
            }
        )

        binding.recyclerView.apply {
            layoutManager = if (isGridView) GridLayoutManager(context, 3) else LinearLayoutManager(context)
            adapter = fileAdapter
        }
    }

    private fun loadFiles() {
        // In a real app, this would use a ViewModel and the FileManager
        // For the template, we show the list refresh logic
        // val files = fileManager.listFiles(currentPath)
        // fileAdapter.submitList(files)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
