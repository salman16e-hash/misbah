package com.foldercam.manager.domain

import android.content.Context
import android.os.Environment
import java.io.File

class DirectFileManager(private val context: Context) : FileManager {
    
    override fun listFiles(path: String): List<FileEntry> {
        val root = if (path == "/") Environment.getExternalStorageDirectory() else File(path)
        return root.listFiles()?.map {
            FileEntry(
                name = it.name,
                path = it.absolutePath,
                size = it.length(),
                lastModified = it.lastModified(),
                isDirectory = it.isDirectory,
                type = if (it.isDirectory) "folder" else it.extension
            )
        } ?: emptyList()
    }

    override fun createFolder(parentPath: String, name: String): Boolean {
        val folder = File(parentPath, name)
        return if (!folder.exists()) folder.mkdirs() else false
    }

    override fun deleteFile(path: String): Boolean {
        val file = File(path)
        return if (file.isDirectory) file.deleteRecursively() else file.delete()
    }

    override fun renameFile(path: String, newName: String): Boolean {
        val file = File(path)
        val dest = File(file.parent, newName)
        return file.renameTo(dest)
    }

    override fun getSaveUri(folderPath: String, fileName: String): android.net.Uri? {
        val file = File(folderPath, fileName)
        return android.net.Uri.fromFile(file)
    }
}
