# FolderCam Manager - Final Android 12 Project (Native)

Aapka FolderCam Manager ab puri tarah se taiyaar hai. Ye koi website nahi hai, balki ek **Asli Android Project** hai jo offline kaam karega.

### 🌟 Native Features:
- **Offline Storage**: Android 12 ki binary logic ke hisaab se `MediaStore` aur `Scoped Storage` use kiya gaya hai.
- **Auto-Rename**: Photo khichne se pehle aapse naam poochha jayega, aur OK karte hi wo photo usi folder mein save ho jayegi jahan aap khade hain.
- **Full Manager**: Mi File Manager ki tarah Delete, Rename, aur Open options built-in hain.
- **Android 12 Support**: `MANAGE_EXTERNAL_STORAGE` permission ke saath ye Android 12, 13 aur 14 par behtareen chalega.

### 📁 Project Structure (Jo aap unzip karenge):
- **`/android-app`**: Ye aapka primary Android Studio project folder hai.
- **`app/src/main/java`**: Ismein saara Kotlin code hai.
- **`app/src/main/res/layout`**: Ismein camera aur explorer ke XML designs hain.

### 🚀 Kaise chalayein:
1.  **ZIP Download karein**: Sabse upar diye gaye button se ZIP download karein.
2.  **Extract & Open**: `/android-app` folder ko Android Studio mein open karein.
3.  **Run**: USB se phone connect karein ya Emulator par 'Run' button dabayein.
4.  **Permission**: Pehli baar app khulne par Storage permission allow karein.

Ab aapka app tayyar hai! Bina internet ke, bina kisi website ke, ye phone ki memories ko folders mein organize karne ke liye Mi File Manager jaisa experience dega.
