/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import FileBrowser from './components/FileBrowser';
import Camera from './components/Camera';
import FileViewer from './components/FileViewer';
import Settings from './components/Settings';
import { FileEntry, AppSettings } from './types';
import { VirtualFileSystem } from './services/fileFileSystem';

const fs = new VirtualFileSystem();

export default function App() {
  const [currentView, setCurrentView] = useState<'browser' | 'camera' | 'settings'>('browser');
  const [activeFolderId, setActiveFolderId] = useState<string | null>(null);
  const [viewingFile, setViewingFile] = useState<FileEntry | null>(null);
  const [settings, setSettings] = useState<AppSettings>({
    cameraQuality: 'high',
    fileNamingPattern: 'IMG',
    defaultView: 'list',
    showHiddenFiles: false,
    videoEnabled: true
  });

  const handleOpenCamera = (folderId: string | null) => {
    setActiveFolderId(folderId);
    setCurrentView('camera');
  };

  const handleCapture = () => {
    // Files are refreshed inside components but we can force update if needed
  };

  const handleDeleteFile = (id: string) => {
    fs.deleteEntry(id);
    // Refresh handled by component state usually, but for global consistency:
    window.dispatchEvent(new Event('fs_change'));
  };

  const handleRenameFile = (id: string) => {
    const entry = viewingFile;
    if (entry) {
      const newName = prompt('Rename to:', entry.name);
      if (newName) {
        fs.renameEntry(id, newName);
        setViewingFile({ ...entry, name: newName });
      }
    }
  };

  return (
    <div className="h-screen w-screen bg-gray-100 flex items-center justify-center overflow-hidden">
      {/* Simulation Frame (Android vibe) */}
      <div className="w-full h-full max-w-md bg-white shadow-2xl relative overflow-hidden flex flex-col md:h-[844px] md:rounded-[40px] md:border-[8px] md:border-gray-900">
        
        {/* Status Bar simulation */}
        <div className="h-10 bg-white flex items-center justify-between px-6 shrink-0 z-40">
          <span className="text-xs font-semibold">10:30</span>
          <div className="flex gap-2 items-center">
            <div className="w-4 h-4 bg-gray-900 rounded-full flex items-center justify-center">
              <div className="w-1.5 h-1.5 bg-white rounded-full"></div>
            </div>
            <div className="w-4 h-2.5 bg-gray-900 rounded-[2px] relative">
              <div className="absolute -right-1 top-0.5 w-1 h-1.5 bg-gray-900 rounded-sm"></div>
            </div>
          </div>
        </div>

        <div className="flex-1 overflow-hidden relative">
          {currentView === 'browser' && (
            <FileBrowser 
              onOpenCamera={handleOpenCamera}
              onOpenSettings={() => setCurrentView('settings')}
              onViewFile={setViewingFile}
            />
          )}

          {currentView === 'camera' && (
            <Camera 
              folderId={activeFolderId}
              onClose={() => setCurrentView('browser')}
              onCapture={handleCapture}
            />
          )}

          {currentView === 'settings' && (
            <Settings 
              settings={settings}
              onUpdate={(s) => setSettings(prev => ({ ...prev, ...s }))}
              onClose={() => setCurrentView('browser')}
            />
          )}

          <FileViewer 
            file={viewingFile}
            onClose={() => setViewingFile(null)}
            onDelete={handleDeleteFile}
            onRename={handleRenameFile}
          />
        </div>

        {/* Home indicator simulation */}
        <div className="h-8 bg-white flex items-center justify-center shrink-0 z-40">
          <div className="w-32 h-1 bg-gray-200 rounded-full"></div>
        </div>
      </div>
    </div>
  );
}

