export type FileType = 'folder' | 'image' | 'video' | 'audio' | 'document' | 'apk' | 'unknown';

export interface FileEntry {
  id: string;
  name: string;
  type: FileType;
  size: number;
  lastModified: number;
  path: string;
  content?: string; // For images/videos, this will be the URL or base64
  parentId: string | null;
}

export interface FolderState {
  currentPath: string;
  files: FileEntry[];
  breadcrumbs: { name: string; id: string | null }[];
}

export interface AppSettings {
  cameraQuality: 'low' | 'medium' | 'high';
  fileNamingPattern: string;
  defaultView: 'list' | 'grid';
  showHiddenFiles: boolean;
  videoEnabled: boolean;
}
