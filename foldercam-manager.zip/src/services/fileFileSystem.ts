import { FileEntry, FileType } from '../types';
import { get, set, del } from 'idb-keyval';

const STRUCTURE_KEY = 'foldercam_structure';

const INITIAL_FILES: FileEntry[] = [
  { id: 'root_dcim', name: 'DCIM', type: 'folder', size: 0, lastModified: Date.now(), path: '/DCIM', parentId: null },
  { id: 'root_downloads', name: 'Downloads', type: 'folder', size: 0, lastModified: Date.now(), path: '/Downloads', parentId: null },
  { id: 'root_music', name: 'Music', type: 'folder', size: 0, lastModified: Date.now(), path: '/Music', parentId: null },
  { id: 'root_pictures', name: 'Pictures', type: 'folder', size: 0, lastModified: Date.now(), path: '/Pictures', parentId: null },
];

export class VirtualFileSystem {
  private files: FileEntry[] = [];

  constructor() {
    const stored = localStorage.getItem(STRUCTURE_KEY);
    if (stored) {
      this.files = JSON.parse(stored);
    } else {
      this.files = INITIAL_FILES;
      this.saveStructure();
    }
  }

  private saveStructure() {
    localStorage.setItem(STRUCTURE_KEY, JSON.stringify(this.files));
    window.dispatchEvent(new Event('fs_change'));
  }

  getFiles(parentId: string | null): FileEntry[] {
    return this.files.filter(f => f.parentId === parentId);
  }

  async getFileContent(id: string): Promise<string | undefined> {
    return await get(`content_${id}`);
  }

  getPath(folderId: string | null): string {
    if (!folderId) return '/';
    const folder = this.files.find(f => f.id === folderId);
    return folder ? folder.path : '/';
  }

  getBreadcrumbs(folderId: string | null): { name: string; id: string | null }[] {
    const crumbs: { name: string; id: string | null }[] = [{ name: 'Internal Storage', id: null }];
    if (!folderId) return crumbs;

    const pathParts: { name: string; id: string }[] = [];
    let current: FileEntry | undefined = this.files.find(f => f.id === folderId);
    
    while (current) {
      pathParts.unshift({ name: current.name, id: current.id });
      current = this.files.find(f => f.id === current?.parentId);
    }

    return [...crumbs, ...pathParts];
  }

  createFolder(name: string, parentId: string | null): FileEntry {
    const parentPath = this.getPath(parentId);
    const newFolder: FileEntry = {
      id: Math.random().toString(36).substr(2, 9),
      name,
      type: 'folder',
      size: 0,
      lastModified: Date.now(),
      path: `${parentPath === '/' ? '' : parentPath}/${name}`,
      parentId
    };
    this.files.push(newFolder);
    this.saveStructure();
    return newFolder;
  }

  async addFile(name: string, type: FileType, size: number, content: string, parentId: string | null): Promise<FileEntry> {
    const id = Math.random().toString(36).substr(2, 9);
    const parentPath = this.getPath(parentId);
    
    const newFile: FileEntry = {
      id,
      name,
      type,
      size,
      lastModified: Date.now(),
      path: `${parentPath === '/' ? '' : parentPath}/${name}`,
      parentId
    };

    // Store large content in IndexedDB
    await set(`content_${id}`, content);
    
    this.files.push(newFile);
    this.saveStructure();
    return newFile;
  }

  async deleteEntry(id: string) {
    const toDelete = [id];
    const findChildren = (pid: string) => {
      this.files.forEach(f => {
        if (f.parentId === pid) {
          toDelete.push(f.id);
          if (f.type === 'folder') findChildren(f.id);
        }
      });
    };
    
    const entry = this.files.find(f => f.id === id);
    if (entry?.type === 'folder') findChildren(id);

    // Remove contents from IndexedDB
    for (const deleteId of toDelete) {
      await del(`content_${deleteId}`);
    }

    this.files = this.files.filter(f => !toDelete.includes(f.id));
    this.saveStructure();
  }

  renameEntry(id: string, newName: string) {
    const entry = this.files.find(f => f.id === id);
    if (entry) {
      entry.name = newName;
      entry.lastModified = Date.now();
      this.saveStructure();
    }
  }
}
