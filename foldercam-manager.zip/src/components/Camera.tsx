import React, { useRef, useState, useEffect } from 'react';
import { Camera as CameraIcon, X, RefreshCw, Zap, Video, Square, Image as ImageIcon } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { VirtualFileSystem } from '../services/fileFileSystem';
import { cn } from '../lib/utils';

const fs = new VirtualFileSystem();

interface CameraProps {
  folderId: string | null;
  onClose: () => void;
  onCapture: () => void;
}

export default function Camera({ folderId, onClose, onCapture }: CameraProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [flash, setFlash] = useState(false);
  const [lastSaved, setLastSaved] = useState<string | null>(null);

  useEffect(() => {
    startCamera();
    return () => stopCamera();
  }, []);

  const startCamera = async () => {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      console.error('Camera API not supported');
      alert('Your browser does not support camera access.');
      onClose();
      return;
    }

    try {
      const attempts = [
        { video: { facingMode: { ideal: 'environment' } }, audio: false },
        { video: { facingMode: 'user' }, audio: false },
        { video: true, audio: false }
      ];

      for (const constraints of attempts) {
        try {
          const s = await navigator.mediaDevices.getUserMedia(constraints);
          setStream(s);
          if (videoRef.current) {
            videoRef.current.srcObject = s;
          }
          return; // Success
        } catch (e) {
          console.warn(`Camera attempt failed with ${JSON.stringify(constraints)}:`, e);
        }
      }

      // If all hardware attempts fail, enter "Simulation Mode"
      console.warn('All camera hardware attempts failed. Entering Simulation Mode.');
      alert('Camera hardware not detected. Using "Prototype Simulation Mode" with sample images.');
    } catch (err) {
      console.error('Final Camera initialization error:', err);
      alert('Could not access any camera. Please ensure permissions are granted.');
      onClose();
    }
  };

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
    }
  };

  const takePhoto = async () => {
    // Simulation Mode
    if (!stream || !videoRef.current) {
      const mockImages = [
        'https://picsum.photos/seed/folder1/1080/1920',
        'https://picsum.photos/seed/folder2/1080/1920',
        'https://picsum.photos/seed/folder3/1080/1920'
      ];
      const randomImage = mockImages[Math.floor(Math.random() * mockImages.length)];
      
      const fileName = `SIM_IMG_${new Date().toISOString().replace(/[:.]/g, '-')}.jpg`;
      await fs.addFile(fileName, 'image', 500000, randomImage, folderId);
      
      setFlash(true);
      setTimeout(() => setFlash(false), 150);
      setLastSaved(randomImage);
      setTimeout(() => setLastSaved(null), 2000);
      onCapture();
      return;
    }

    if (!canvasRef.current) return;
    const context = canvasRef.current.getContext('2d');
    if (!context) return;

    canvasRef.current.width = videoRef.current.videoWidth;
    canvasRef.current.height = videoRef.current.videoHeight;
    context.drawImage(videoRef.current, 0, 0);

    const dataUrl = canvasRef.current.toDataURL('image/jpeg', 0.9);
    
    // Prompt for filename
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    const defaultName = `IMG_${timestamp}`;
    const userFileName = prompt('Enter a name for this photo:', defaultName);
    
    if (userFileName === null) return; // User cancelled capture
    
    const fileName = `${userFileName || defaultName}.jpg`;
    await fs.addFile(fileName, 'image', dataUrl.length, dataUrl, folderId);
    
    setFlash(true);
    setTimeout(() => setFlash(false), 150);
    setLastSaved(dataUrl);
    setTimeout(() => setLastSaved(null), 2000);
    onCapture();
  };

  return (
    <div className="fixed inset-0 z-[100] bg-black flex flex-col items-center justify-center">
      {/* Viewport */}
      <div className="relative w-full h-full max-w-md bg-black overflow-hidden flex items-center justify-center">
        <video 
          ref={videoRef} 
          autoPlay 
          playsInline 
          muted 
          className="w-full h-full object-cover"
        />
        <canvas ref={canvasRef} className="hidden" />

        {/* HUD Overlay */}
        <div className="absolute inset-0 flex flex-col justify-between p-6 pointer-events-none">
          <header className="flex items-center justify-between pointer-events-auto">
            <button onClick={onClose} className="p-3 bg-black/40 backdrop-blur-md rounded-full text-white">
              <X size={24} />
            </button>
            <div className="flex gap-4">
              <button className="p-3 bg-black/40 backdrop-blur-md rounded-full text-white">
                <Zap size={20} />
              </button>
              <button className="p-3 bg-black/40 backdrop-blur-md rounded-full text-white">
                <RefreshCw size={20} />
              </button>
            </div>
          </header>

          <footer className="flex items-center justify-around pointer-events-auto pb-4">
            <div className="w-14 h-14 bg-white/10 backdrop-blur-md rounded-full flex items-center justify-center border border-white/20 overflow-hidden">
              {lastSaved ? (
                <img src={lastSaved} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              ) : (
                <ImageIcon className="text-white/40" size={24} />
              )}
            </div>

            <button 
              onClick={takePhoto}
              className="w-20 h-20 bg-white rounded-full flex items-center justify-center ring-4 ring-white/30 active:scale-90 transition-transform shadow-2xl"
            >
              <div className="w-16 h-16 rounded-full border-4 border-gray-100" />
            </button>

            <button className="w-14 h-14 bg-white/10 backdrop-blur-md rounded-full flex items-center justify-center text-white border border-white/20">
              <Video size={24} />
            </button>
          </footer>
        </div>

        {/* Save Notification */}
        <AnimatePresence>
          {lastSaved && (
            <motion.div 
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 20, opacity: 0 }}
              className="absolute bottom-32 left-1/2 -translate-x-1/2 px-4 py-2 bg-blue-600/90 backdrop-blur-lg text-white rounded-full text-sm font-medium shadow-lg"
            >
              Photo saved to folder
            </motion.div>
          )}
        </AnimatePresence>

        {/* Flash Effect */}
        {flash && (
          <div className="absolute inset-0 bg-white z-50 transition-opacity duration-150 animate-pulse" />
        )}
      </div>
    </div>
  );
}
