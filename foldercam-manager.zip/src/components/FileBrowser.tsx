import React, { useState, useEffect } from 'react';
import { 
  Folder, 
  Image as ImageIcon, 
  Video, 
  Music, 
  File, 
  MoreVertical, 
  Search, 
  ArrowLeft, 
  LayoutGrid, 
  List, 
  Plus, 
  Camera,
  Settings as SettingsIcon,
  X,
  Share2,
  Trash2,
  Edit2,
  Info,
  Eye
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { FileEntry, FileType, FolderState, AppSettings } from '../types';
import { VirtualFileSystem } from '../services/fileFileSystem';
import { cn, formatFileSize } from '../lib/utils';
import { format } from 'date-fns';

const fs = new VirtualFileSystem();

interface FileBrowserProps {
  onOpenCamera: (folderId: string | null) => void;
  onOpenSettings: () => void;
  onViewFile: (file: FileEntry) => void;
}

export default function FileBrowser({ onOpenCamera, onOpenSettings, onViewFile }: FileBrowserProps) {
  const [currentFolderId, setCurrentFolderId] = useState<string | null>(null);
  const [files, setFiles] = useState<FileEntry[]>([]);
  const [viewMode, setViewMode] = useState<'list' | 'grid'>('list');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedItems, setSelectedItems] = useState<string[]>([]);
  const [isMultiSelect, setIsMultiSelect] = useState(false);
  const [contextMenu, setContextMenu] = useState<{ id: string, x: number, y: number } | null>(null);

  const [fileContents, setFileContents] = useState<Record<string, string>>({});

  useEffect(() => {
    refreshFiles();
    const handleFsChange = () => refreshFiles();
    window.addEventListener('fs_change', handleFsChange);
    return () => window.removeEventListener('fs_change', handleFsChange);
  }, [currentFolderId]);

  const refreshFiles = async () => {
    const freshFiles = fs.getFiles(currentFolderId);
    setFiles(freshFiles);
    
    // Pre-fetch thumbnails for images in view
    const contents: Record<string, string> = {};
    for (const f of freshFiles) {
      if (f.type === 'image') {
        const content = await fs.getFileContent(f.id);
        if (content) contents[f.id] = content;
      }
    }
    setFileContents(contents);
    
    setSelectedItems([]);
    setIsMultiSelect(false);
  };

  const breadcrumbs = fs.getBreadcrumbs(currentFolderId);

  const filteredFiles = files.filter(f => 
    f.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleFolderClick = (id: string) => {
    if (isMultiSelect) {
      toggleSelection(id);
    } else {
      setCurrentFolderId(id);
    }
  };

  const handleFileClick = (file: FileEntry) => {
    if (isMultiSelect) {
      toggleSelection(file.id);
    } else {
      if (file.type === 'image' || file.type === 'video') {
        onViewFile(file);
      }
    }
  };

  const toggleSelection = (id: string) => {
    setSelectedItems(prev => 
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  const handleLongPress = (id: string) => {
    setIsMultiSelect(true);
    setSelectedItems([id]);
  };

  const handleCreateFolder = () => {
    const name = prompt('Enter folder name:');
    if (name) {
      fs.createFolder(name, currentFolderId);
      refreshFiles();
    }
  };

  const handleDelete = (id: string) => {
    if (confirm('Are you sure you want to delete this?')) {
      fs.deleteEntry(id);
      refreshFiles();
      setContextMenu(null);
    }
  };

  const handleRename = (id: string) => {
    const entry = files.find(f => f.id === id);
    const newName = prompt('Rename to:', entry?.name);
    if (newName) {
      fs.renameEntry(id, newName);
      refreshFiles();
      setContextMenu(null);
    }
  };

  const handleBatchDelete = () => {
    if (confirm(`Delete ${selectedItems.length} items?`)) {
      selectedItems.forEach(id => fs.deleteEntry(id));
      refreshFiles();
    }
  };

  const getIcon = (type: FileType) => {
    switch (type) {
      case 'folder': return <Folder className="text-blue-500 fill-blue-500/10" />;
      case 'image': return <ImageIcon className="text-purple-500" />;
      case 'video': return <Video className="text-red-500" />;
      case 'audio': return <Music className="text-green-500" />;
      default: return <File className="text-gray-400" />;
    }
  };

  return (
    <div className="flex flex-col h-full bg-white text-gray-900 font-sans">
      {/* Toolbar */}
      <header className="px-4 py-3 flex items-center justify-between border-b border-gray-100 bg-white/80 backdrop-blur-md sticky top-0 z-20">
        <div className="flex items-center gap-3">
          {currentFolderId && (
            <button 
              onClick={() => {
                const parent = breadcrumbs[breadcrumbs.length - 2];
                setCurrentFolderId(parent?.id ?? null);
              }}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            >
              <ArrowLeft size={24} />
            </button>
          )}
          <h1 className="font-semibold text-lg max-w-[150px] truncate">
            {isMultiSelect ? `${selectedItems.length} selected` : (breadcrumbs[breadcrumbs.length - 1].name)}
          </h1>
        </div>

        <div className="flex items-center gap-1">
          {isMultiSelect ? (
            <>
              <button onClick={handleBatchDelete} className="p-2 hover:bg-red-50 text-red-500 rounded-full"><Trash2 size={20} /></button>
              <button onClick={() => setIsMultiSelect(false)} className="p-2 hover:bg-gray-100 rounded-full"><X size={20} /></button>
            </>
          ) : (
            <>
              <button onClick={() => setViewMode(v => v === 'list' ? 'grid' : 'list')} className="p-2 hover:bg-gray-100 rounded-full">
                {viewMode === 'list' ? <LayoutGrid size={20} /> : <List size={20} />}
              </button>
              <button onClick={handleCreateFolder} className="p-2 hover:bg-gray-100 rounded-full"><Plus size={20} /></button>
              <button onClick={onOpenSettings} className="p-2 hover:bg-gray-100 rounded-full"><SettingsIcon size={20} /></button>
            </>
          )}
        </div>
      </header>

      {/* Search Bar */}
      {!isMultiSelect && (
        <div className="px-4 py-2">
          <div className="relative group">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-blue-500 transition-colors" size={18} />
            <input 
              type="text" 
              placeholder="Search files..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-gray-100 border-none rounded-2xl py-2.5 pl-10 pr-4 text-sm focus:ring-2 focus:ring-blue-500/20 transition-all outline-none"
            />
          </div>
        </div>
      )}

      {/* File List */}
      <main className="flex-1 overflow-y-auto px-2">
        <div className={cn(
          "py-2",
          viewMode === 'grid' ? "grid grid-cols-3 gap-2" : "flex flex-col"
        )}>
          {filteredFiles.length === 0 && (
            <div className="flex flex-col items-center justify-center py-20 text-gray-400">
              <Folder size={64} strokeWidth={1} className="opacity-20 mb-4" />
              <p>No files found</p>
            </div>
          )}
          
          <AnimatePresence>
            {filteredFiles.map((file) => (
              <motion.div
                key={file.id}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                onContextMenu={(e) => {
                  e.preventDefault();
                  setContextMenu({ id: file.id, x: e.clientX, y: e.clientY });
                }}
                className={cn(
                  "relative rounded-xl cursor-pointer transition-all active:scale-95 group",
                  selectedItems.includes(file.id) ? "bg-blue-50" : "hover:bg-gray-50",
                  viewMode === 'list' ? "flex items-center p-3 gap-4" : "flex flex-col items-center p-4"
                )}
                onClick={() => file.type === 'folder' ? handleFolderClick(file.id) : handleFileClick(file)}
                onContextMenuCapture={(e) => {
                  e.preventDefault();
                  handleLongPress(file.id);
                }}
              >
                <div className={cn(
                  "p-2 rounded-xl transition-colors",
                  viewMode === 'grid' ? "mb-2 bg-gray-50 p-6 flex justify-center w-full aspect-square relative overflow-hidden" : "w-12 h-12 flex items-center justify-center bg-gray-50"
                )}>
                  {file.type === 'image' && fileContents[file.id] ? (
                    <img 
                      src={fileContents[file.id]} 
                      alt={file.name} 
                      className="w-full h-full object-cover rounded-sm"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    React.cloneElement(getIcon(file.type) as React.ReactElement, { size: viewMode === 'grid' ? 32 : 24 })
                  )}
                  {selectedItems.includes(file.id) && (
                    <div className="absolute inset-0 bg-blue-500/20 flex items-center justify-center">
                      <div className="bg-blue-500 text-white rounded-full p-1 border-2 border-white">
                        <Plus className="rotate-45" size={12} />
                      </div>
                    </div>
                  )}
                  {viewMode === 'grid' && !isMultiSelect && (
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        setContextMenu({ id: file.id, x: e.clientX, y: e.clientY });
                      }}
                      className="absolute top-1 right-1 p-1 bg-white/80 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <MoreVertical size={14} />
                    </button>
                  )}
                </div>

                <div className={cn(
                  "flex-1",
                  viewMode === 'grid' ? "text-center w-full" : ""
                )}>
                  <p className={cn(
                    "font-medium text-sm text-gray-800 line-clamp-1",
                    viewMode === 'grid' ? "mt-1" : ""
                  )}>{file.name}</p>
                  {viewMode === 'list' && (
                    <div className="flex gap-2 text-[11px] text-gray-400 mt-0.5">
                      {file.type !== 'folder' && <span>{formatFileSize(file.size)}</span>}
                      <span>{format(file.lastModified, 'MMM d, HH:mm')}</span>
                    </div>
                  )}
                </div>

                {viewMode === 'list' && !isMultiSelect && (
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      setContextMenu({ id: file.id, x: e.clientX, y: e.clientY });
                    }}
                    className="p-2 opacity-0 group-hover:opacity-100 hover:bg-gray-100 rounded-full transition-all"
                  >
                    <MoreVertical size={16} />
                  </button>
                )}
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </main>

      {/* FAB */}
      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.9 }}
        onClick={() => onOpenCamera(currentFolderId)}
        className="fixed bottom-6 right-6 w-16 h-16 bg-blue-600 text-white rounded-2xl shadow-xl shadow-blue-200 flex items-center justify-center z-30"
      >
        <Camera size={28} strokeWidth={2.5} />
      </motion.button>

      {/* Context Menu Overlay */}
      {contextMenu && (
        <div 
          className="fixed inset-0 z-50 overflow-hidden"
          onClick={() => setContextMenu(null)}
        >
          <div 
            className="absolute bg-white rounded-2xl shadow-2xl border border-gray-100 w-56 py-2"
            style={{ 
              top: Math.min(contextMenu.y, window.innerHeight - 300), 
              left: Math.min(contextMenu.x, window.innerWidth - 240) 
            }}
          >
            <button 
              onClick={() => {
                const file = files.find(f => f.id === contextMenu.id);
                if (file) {
                  if (file.type === 'folder') setCurrentFolderId(file.id);
                  else onViewFile(file);
                }
                setContextMenu(null);
              }} 
              className="w-full text-left px-4 py-3 flex items-center gap-3 hover:bg-gray-50"
            >
              <Eye size={18} className="text-gray-400" /> Open
            </button>
            <button onClick={() => handleRename(contextMenu.id)} className="w-full text-left px-4 py-3 flex items-center gap-3 hover:bg-gray-50"><Edit2 size={18} className="text-gray-400" /> Rename</button>
            <button className="w-full text-left px-4 py-3 flex items-center gap-3 hover:bg-gray-50"><Share2 size={18} className="text-gray-400" /> Share</button>
            <button className="w-full text-left px-4 py-3 flex items-center gap-3 hover:bg-gray-50"><Info size={18} className="text-gray-400" /> Details</button>
            <div className="h-px bg-gray-100 my-1"></div>
            <button onClick={() => handleDelete(contextMenu.id)} className="w-full text-left px-4 py-3 flex items-center gap-3 hover:bg-red-50 text-red-500 font-medium"><Trash2 size={18} /> Delete</button>
          </div>
        </div>
      )}
    </div>
  );
}
