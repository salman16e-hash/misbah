import React from 'react';
import { X, Camera, Eye, FileText, Video as VideoIcon, ChevronRight, Monitor, Languages, Smartphone } from 'lucide-react';
import { motion } from 'motion/react';
import { AppSettings } from '../types';

interface SettingsProps {
  settings: AppSettings;
  onUpdate: (settings: Partial<AppSettings>) => void;
  onClose: () => void;
}

export default function Settings({ settings, onUpdate, onClose }: SettingsProps) {
  return (
    <div className="fixed inset-0 z-[120] bg-gray-50 flex flex-col">
      <header className="px-4 py-4 flex items-center gap-4 bg-white border-b border-gray-200">
        <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full transition-colors">
          <X size={24} />
        </button>
        <h1 className="text-xl font-semibold">Settings</h1>
      </header>

      <main className="flex-1 overflow-y-auto pt-4 space-y-4">
        {/* Camera Section */}
        <section className="bg-white px-4 border-y border-gray-200">
          <h2 className="py-4 text-sm font-semibold text-blue-600 uppercase tracking-wider">Camera</h2>
          
          <div className="flex items-center justify-between py-4 border-b border-gray-100 cursor-pointer">
            <div className="flex items-center gap-4">
              <div className="p-2 bg-gray-100 rounded-xl"><Camera size={20} className="text-gray-600" /></div>
              <div>
                <p className="font-medium">Camera Quality</p>
                <p className="text-xs text-gray-500 uppercase">{settings.cameraQuality}</p>
              </div>
            </div>
            <select 
              value={settings.cameraQuality}
              onChange={(e) => onUpdate({ cameraQuality: e.target.value as any })}
              className="bg-transparent border-none text-blue-600 font-medium focus:ring-0 cursor-pointer"
            >
              <option value="low">Low</option>
              <option value="medium">Medium</option>
              <option value="high">High</option>
            </select>
          </div>

          <div className="flex items-center justify-between py-4 border-b border-gray-100">
            <div className="flex items-center gap-4">
              <div className="p-2 bg-gray-100 rounded-xl"><FileText size={20} className="text-gray-600" /></div>
              <div>
                <p className="font-medium">File Naming</p>
                <p className="text-xs text-gray-500">Prefix for photos</p>
              </div>
            </div>
            <input 
              type="text" 
              value={settings.fileNamingPattern}
              onChange={(e) => onUpdate({ fileNamingPattern: e.target.value })}
              className="w-24 text-right bg-transparent border-none text-blue-600 font-medium focus:ring-0"
            />
          </div>

          <div className="flex items-center justify-between py-4">
            <div className="flex items-center gap-4">
              <div className="p-2 bg-gray-100 rounded-xl"><VideoIcon size={20} className="text-gray-600" /></div>
              <div>
                <p className="font-medium">Video Recording</p>
                <p className="text-xs text-gray-500">Enable video capture</p>
              </div>
            </div>
            <button 
              onClick={() => onUpdate({ videoEnabled: !settings.videoEnabled })}
              className={cn(
                "w-12 h-6 rounded-full transition-colors relative",
                settings.videoEnabled ? "bg-blue-600" : "bg-gray-300"
              )}
            >
              <div className={cn(
                "absolute top-1 w-4 h-4 bg-white rounded-full transition-transform",
                settings.videoEnabled ? "translate-x-7" : "translate-x-1"
              )} />
            </button>
          </div>
        </section>

        {/* Appearance Section */}
        <section className="bg-white px-4 border-y border-gray-200">
          <h2 className="py-4 text-sm font-semibold text-blue-600 uppercase tracking-wider">Appearance</h2>
          
          <div className="flex items-center justify-between py-4 border-b border-gray-100">
            <div className="flex items-center gap-4">
              <div className="p-2 bg-gray-100 rounded-xl"><Eye size={20} className="text-gray-600" /></div>
              <div>
                <p className="font-medium">Default View</p>
                <p className="text-xs text-gray-500 uppercase">{settings.defaultView}</p>
              </div>
            </div>
            <select 
              value={settings.defaultView}
              onChange={(e) => onUpdate({ defaultView: e.target.value as any })}
              className="bg-transparent border-none text-blue-600 font-medium focus:ring-0 cursor-pointer"
            >
              <option value="list">List</option>
              <option value="grid">Grid</option>
            </select>
          </div>

          <div className="flex items-center justify-between py-4">
            <div className="flex items-center gap-4">
              <div className="p-2 bg-gray-100 rounded-xl"><Monitor size={20} className="text-gray-600" /></div>
              <div>
                <p className="font-medium">Show Hidden Files</p>
                <p className="text-xs text-gray-500">Show files starting with .</p>
              </div>
            </div>
            <button 
              onClick={() => onUpdate({ showHiddenFiles: !settings.showHiddenFiles })}
              className={cn(
                "w-12 h-6 rounded-full transition-colors relative",
                settings.showHiddenFiles ? "bg-blue-600" : "bg-gray-300"
              )}
            >
              <div className={cn(
                "absolute top-1 w-4 h-4 bg-white rounded-full transition-transform",
                settings.showHiddenFiles ? "translate-x-7" : "translate-x-1"
              )} />
            </button>
          </div>
        </section>

        {/* System Info */}
        <section className="px-8 py-8 text-center">
          <div className="inline-block p-4 bg-white rounded-3xl shadow-sm mb-4">
            <Smartphone size={32} className="text-blue-600" />
          </div>
          <p className="text-gray-900 font-semibold">FolderCam Manager</p>
          <p className="text-gray-400 text-sm">Version 1.0.4</p>
          <div className="mt-8 pt-8 border-t border-gray-200">
            <p className="text-xs text-gray-400">© 2026 FolderCam Team • Android 14 (API 34)</p>
          </div>
        </section>
      </main>
    </div>
  );
}

function cn(...classes: string[]) {
  return classes.filter(Boolean).join(' ');
}
