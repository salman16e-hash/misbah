import React, { useEffect, useState } from 'react';
import { X, Share2, Trash2, Edit2, Info, ChevronLeft, ChevronRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { FileEntry } from '../types';
import { format } from 'date-fns';
import { formatFileSize } from '../lib/utils';
import { VirtualFileSystem } from '../services/fileFileSystem';

const fs = new VirtualFileSystem();

interface FileViewerProps {
  file: FileEntry | null;
  onClose: () => void;
  onDelete: (id: string) => void;
  onRename: (id: string) => void;
}

export default function FileViewer({ file, onClose, onDelete, onRename }: FileViewerProps) {
  const [content, setContent] = useState<string | null>(null);

  useEffect(() => {
    if (file) {
      fs.getFileContent(file.id).then(setContent);
    } else {
      setContent(null);
    }
  }, [file]);

  if (!file) return null;

  return (
    <AnimatePresence>
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[110] bg-black/95 flex flex-col"
      >
        <header className="p-4 flex items-center justify-between text-white bg-black/50 backdrop-blur-md">
          <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full">
            <X size={24} />
          </button>
          <div className="text-center overflow-hidden flex-1 px-4">
            <h2 className="text-sm font-medium truncate">{file.name}</h2>
            <p className="text-[10px] opacity-60 uppercase tracking-wider">{file.type}</p>
          </div>
          <button className="p-2 hover:bg-white/10 rounded-full">
            <Share2 size={24} />
          </button>
        </header>

        <main className="flex-1 flex items-center justify-center relative overflow-hidden">
          {file.type === 'image' && content && (
            <motion.img 
              layoutId={file.id}
              src={content} 
              className="max-h-full max-w-full object-contain"
              referrerPolicy="no-referrer"
            />
          )}
          {file.type === 'video' && content && (
            <video 
              src={content} 
              controls 
              autoPlay
              className="max-h-full max-w-full"
            />
          )}
          {!content && (
             <div className="text-white/40 animate-pulse">Loading content...</div>
          )}
        </main>

        <footer className="p-6 bg-black/50 backdrop-blur-md text-white">
          <div className="flex items-center justify-around mb-6">
            <button 
              onClick={() => onRename(file.id)}
              className="flex flex-col items-center gap-2 opacity-80 hover:opacity-100 transition-opacity"
            >
              <div className="p-3 bg-white/10 rounded-full"><Edit2 size={24} /></div>
              <span className="text-xs">Rename</span>
            </button>
            <button className="flex flex-col items-center gap-2 opacity-80 hover:opacity-100 transition-opacity">
              <div className="p-3 bg-white/10 rounded-full"><Share2 size={24} /></div>
              <span className="text-xs">Share</span>
            </button>
            <button 
              onClick={() => {
                if (confirm('Delete this file?')) {
                  onDelete(file.id);
                  onClose();
                }
              }}
              className="flex flex-col items-center gap-2 text-red-400 hover:text-red-300 transition-colors"
            >
              <div className="p-3 bg-red-500/20 rounded-full"><Trash2 size={24} /></div>
              <span className="text-xs">Delete</span>
            </button>
            <button className="flex flex-col items-center gap-2 opacity-80 hover:opacity-100 transition-opacity">
              <div className="p-3 bg-white/10 rounded-full"><Info size={24} /></div>
              <span className="text-xs">Details</span>
            </button>
          </div>

          <div className="bg-white/5 rounded-2xl p-4 text-sm space-y-2 opacity-80">
            <div className="flex justify-between">
              <span className="text-white/60">Size</span>
              <span>{formatFileSize(file.size)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-white/60">Date</span>
              <span>{format(file.lastModified, 'PPP p')}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-white/60">Path</span>
              <span className="truncate max-w-[200px]">{file.path}</span>
            </div>
          </div>
        </footer>
      </motion.div>
    </AnimatePresence>
  );
}
