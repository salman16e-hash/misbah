package com.foldercam.manager.ui.camera

import android.app.AlertDialog
import android.content.ContentValues
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.Toast
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.foldercam.manager.databinding.FragmentCameraBinding
import java.text.SimpleDateFormat
import java.util.*

class CameraFragment : Fragment() {
    private var _binding: FragmentCameraBinding? = null
    private val binding get() = _binding!!

    private var imageCapture: ImageCapture? = null
    private var targetFolderPath: String? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentCameraBinding.inflate(inflater, container, false)
        targetFolderPath = arguments?.getString("folder_path") ?: "DCIM/FolderCam"
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        startCamera()
        binding.imageCaptureButton.setOnClickListener { showRenameDialogBeforeCapture() }
        binding.btnClose.setOnClickListener { requireActivity().onBackPressed() }
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(requireContext())
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()
            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(binding.viewFinder.surfaceProvider)
            }
            imageCapture = ImageCapture.Builder().build()
            try {
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, imageCapture)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }, ContextCompat.getMainExecutor(requireContext()))
    }

    private fun showRenameDialogBeforeCapture() {
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val defaultName = "IMG_$timestamp"
        
        val input = EditText(requireContext())
        input.setText(defaultName)
        input.setSelectAllOnFocus(true)

        AlertDialog.Builder(requireContext())
            .setTitle("Photo Name")
            .setView(input)
            .setPositiveButton("Capture") { _, _ ->
                val fileName = input.text.toString().trim()
                if (fileName.isNotEmpty()) capturePhoto(fileName)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun sanitizeFileName(name: String): String {
        return name.replace(Regex("[^a-zA-Z0-9_\\-\\(\\)]"), "_")
    }

    private fun capturePhoto(name: String) {
        val imageCapture = imageCapture ?: return
        val sanitizedName = sanitizeFileName(name)
        val fileName = "$sanitizedName.jpg"

        // For Android 10+, we use MediaStore to save directly to a public folder
        // Ensure path starts with a valid root like DCIM or Pictures
        val relativePath = if (targetFolderPath?.startsWith("DCIM", true) == true || 
                               targetFolderPath?.startsWith("Pictures", true) == true) {
            targetFolderPath
        } else {
            "DCIM/FolderCam"
        }

        val contentValues = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Images.Media.RELATIVE_PATH, relativePath)
                put(MediaStore.Images.Media.IS_PENDING, 1) // Atomicity guard
            }
        }

        val outputOptions = ImageCapture.OutputFileOptions
            .Builder(requireContext().contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
            .build()

        imageCapture.takePicture(outputOptions, ContextCompat.getMainExecutor(requireContext()),
            object : ImageCapture.OnImageSavedCallback {
                override fun onError(exc: ImageCaptureException) {
                    Toast.makeText(requireContext(), "Capture Failed: ${exc.message}", Toast.LENGTH_LONG).show()
                }

                override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        val uri = output.savedUri ?: return
                        val updatedValues = ContentValues().apply {
                            put(MediaStore.Images.Media.IS_PENDING, 0)
                        }
                        requireContext().contentResolver.update(uri, updatedValues, null, null)
                    }
                    
                    Toast.makeText(requireContext(), "Photo Saved Successfully!", Toast.LENGTH_SHORT).show()
                    requireActivity().onBackPressed()
                }
            }
        )
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
