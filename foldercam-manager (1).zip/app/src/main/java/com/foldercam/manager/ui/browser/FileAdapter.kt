package com.foldercam.manager.ui.browser

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.foldercam.manager.R
import com.foldercam.manager.databinding.ItemFileBinding
import com.foldercam.manager.domain.FileEntry

class FileAdapter(
    private val onItemClick: (FileEntry) -> Unit,
    private val onItemLongClick: (FileEntry) -> Unit
) : ListAdapter<FileEntry, FileAdapter.FileViewHolder>(FileDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FileViewHolder {
        val binding = ItemFileBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return FileViewHolder(binding)
    }

    override fun onBindViewHolder(holder: FileViewHolder, position: Int) {
        val file = getItem(position)
        holder.bind(file)
    }

    inner class FileViewHolder(private val binding: ItemFileBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(file: FileEntry) {
            binding.fileName.text = file.name
            binding.fileInfo.text = if (file.isDirectory) "Folder" else "${file.size} bytes"
            
            if (file.isDirectory) {
                binding.fileIcon.setImageResource(R.drawable.ic_folder)
            } else {
                binding.fileIcon.setImageResource(R.drawable.ic_file)
            }

            binding.root.setOnClickListener { onItemClick(file) }
            binding.root.setOnLongClickListener {
                onItemLongClick(file)
                true
            }
        }
    }

    class FileDiffCallback : DiffUtil.ItemCallback<FileEntry>() {
        override fun areItemsTheSame(oldItem: FileEntry, newItem: FileEntry): Boolean = oldItem.path == newItem.path
        override fun areContentsTheSame(oldItem: FileEntry, newItem: FileEntry): Boolean = oldItem == newItem
    }
}
